﻿using PokeAPI;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace PokemonAPITest
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }

        public async void GetSpecies()
        {
            PokemonSpecies p = await DataFetcher.GetApiObject<PokemonSpecies>(1);
            textBox1.Text = p.Name;
            textBox2.Text = p.BaseHappiness.ToString();
            textBox3.Text = p.CaptureRate.ToString();
            textBox4.Text = p.FlavorTexts[3].FlavorText;
            textBox5.Text = p.Habitat.Name;
            textBox6.Text = p.GrowthRate.Name;
            textBox7.Text = p.FlavorTexts[1].FlavorText;
            textBox8.Text = p.EggGroups[0].Name;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GetSpecies();
        }
    }
}
