﻿using System;
using System.Windows.Forms;

namespace StarWars2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void planetButton_Click(object sender, EventArgs e)
        {
            int planetID = Convert.ToInt32(textBox2.Text);

            if (0 <= planetID && planetID <= 60)
            {
                Planet t = await JSONHelper.GetPlanet(planetID);
                label1.Text = t.name;
                label2.Text = t.rotation_period;
                label3.Text = t.orbital_period;
                label4.Text = t.diameter;
                label5.Text = t.climate;
                label6.Text = t.gravity;
                label7.Text = t.terrain;
                label8.Text = t.surface_water;
                label9.Text = t.population;
            }
            else
            {
                MessageBox.Show("Invalid Input.");
            }
        }

        private async void peopleButton_Click(object sender, EventArgs e)
        {
            int personID = Convert.ToInt32(textBox2.Text);
            if (0 <= personID && personID <= 83)
            {
                People k = await JSONHelper.GetPeople(personID);
                label10.Text = k.name;
                label11.Text = k.height;
                label12.Text = k.mass;
                label13.Text = k.hair_color;
                label14.Text = k.skin_color;
                label15.Text = k.eye_color;
                label16.Text = k.birth_year;
                label17.Text = k.gender;
                label18.Text = k.homeworld;
                foreach (string x in k.starships)
                {
                    listBox1.Items.Add(x);
                }
            }
            else
            {
                MessageBox.Show("Invalid Input.");
            }

        }

        private async void speciesButton_Click(object sender, EventArgs e)
        {
            int speciesID = Convert.ToInt32(textBox3.Text);
            if (0 <= speciesID && speciesID <= 37)
            {
                Species s = await JSONHelper.GetSpecies(speciesID);
                label19.Text = s.name;
                label20.Text = s.classification;
                label21.Text = s.designation;
                label22.Text = s.average_height;
                label23.Text = s.skin_colors;
                label24.Text = s.hair_colors;
                label25.Text = s.eye_colors;
                label26.Text = s.average_lifespan;
                label27.Text = s.homeworld;
                label28.Text = s.language;
            }
            else
            {
                MessageBox.Show("Invalid Input.");
            }


        }
    }
}
