﻿using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace StarWars2
{
    class JSONHelper
    {
        //https://docs.microsoft.com/en-us/dotnet/api/system.net.http.httpclient?view=netcore-3.1
        static readonly HttpClient client = new HttpClient();
        public static async Task<Planet> GetPlanet(int planetID)
        {
            Planet myDeserializedClass = new Planet();
            // Call async net methods in try/catch block to handle exeptions.
            try
            {
                HttpResponseMessage response = await client.GetAsync("https://swapi.dev/api/planets/" + planetID + "/");
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();


                myDeserializedClass = JsonConvert.DeserializeObject<Planet>(responseBody);
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine("/nException Caught!");
                Console.WriteLine("Messgae :{0} ", e.Message);
            }

            return myDeserializedClass;
        }
        public static async Task<People> GetPeople(int personID)
        {
            People myDeserializedClass = new People();
            // Call async net methods in try/catch block to handle exeptions.
            try
            {
                HttpResponseMessage response = await client.GetAsync("https://swapi.dev/api/people/" + personID + "/");
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();


                myDeserializedClass = JsonConvert.DeserializeObject<People>(responseBody);
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine("/nException Caught!");
                Console.WriteLine("Messgae :{0} ", e.Message);
            }

            return myDeserializedClass;
        }
        public static async Task<Species> GetSpecies(int speciesID)
        {
            Species myDeserializedClass = new Species();
            // Call async net methods in try/catch block to handle exeptions.
            try
            {
                HttpResponseMessage response = await client.GetAsync("https://swapi.dev/api/species/" + speciesID + "/");
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();


                myDeserializedClass = JsonConvert.DeserializeObject<Species>(responseBody);
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine("/nException Caught!");
                Console.WriteLine("Messgae :{0} ", e.Message);
            }

            return myDeserializedClass;
        }
    }
}

